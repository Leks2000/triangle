//Треугольник описан координатами трех своих вершин. Указаны координаты отдельной точки.
// Составить программу, показывающую где находится точка - внутри или вне треугольника.
// Треугольник и точка находятся на координатной плоскости.
//Обратить внимание на обработку ошибок при вводе координат.
// Программа не должна "падать" при вводе неправильных значений
class Coordinate(_x: Double, _y: Double, Bx: Double, By: Double)
{
    open val x = _x
    open val y = _y
    open val bx = Bx
    open val by = By
    open fun Result(){
        println(x.toString() + " " + y.toString())
    }

    fun CheckCoordinate()
    {
        if (x < bx){

        }
    }
    fun Reboot(): Double{
        return (x + y)
    }
}
fun main(args: Array<String>) {
    println("Введите координаты треугольника через пробел: ")
    val cordX = readln().toDouble()
    val cordY = readln().toDouble()
    println("Введитe координаты точки которой хотите проверить принадлежит ли тругольнику или нет через пробел: ")
    var Check = readLine()!!.split(";")
    var Bx = Check[0].toDouble()
    var By = Check[2].toDouble()
    val res = Coordinate(cordX, cordY, Bx, By)
    val ArrayResult: Array<Coordinate> = arrayOf(res)
    ArrayResult.forEach {
        it.Result()
    }
}